import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwnOperatorsComponent } from './own-operators.component';

describe('OwnOperatorsComponent', () => {
  let component: OwnOperatorsComponent;
  let fixture: ComponentFixture<OwnOperatorsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwnOperatorsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwnOperatorsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
