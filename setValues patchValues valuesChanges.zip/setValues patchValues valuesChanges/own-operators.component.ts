import { Component, OnInit } from '@angular/core';
import { Observable, of, from, fromEvent, concat, interval, throwError } from 'rxjs';
import { ajax } from 'rxjs/ajax';
import { mergeMap, filter, tap, catchError, take, takeUntil } from 'rxjs/operators';

import {allBooks, allReaders} from 'src/assets/Data';
import { map } from 'rxjs/internal/operators/map';
import { FormGroup, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';


@Component({
  selector: 'app-own-operators',
  templateUrl: './own-operators.component.html',
  styleUrls: ['./own-operators.component.css']
})
export class OwnOperatorsComponent implements OnInit {
  personalForm: FormGroup;
  DoubleOperator() {
    return map(value => value * 2);
  }

  constructor(private formBuilder: FormBuilder) {
 const source2$ = from(allBooks);
 source2$.subscribe(book => console.log(book.title));
 const s1 = of(1, 2, 3, 4);
  s1.pipe(
          this.DoubleOperator()
        ).subscribe(s => console.log(s));

  }

  ngOnInit() {
      this.personalForm = this.formBuilder.group({
      firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(8)]],
      lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(8)]],
      address: ['', [Validators.required]],
     other: this.formBuilder.group({
                          education: [''],
                          age: [''],
                          gendar: ['male']
                        })
    });

    this.personalForm.get('firstName').valueChanges.subscribe(
      value => {
        console.log(value);
      }
    );


    this.personalForm.get('other').valueChanges.subscribe(
      value => {
        console.log(value);
      }
    );

    // Subscribe to FormGroup valueChanges observable
this.personalForm.valueChanges.subscribe(
  value => {
    console.log(JSON.stringify(value));
  }
);


  }

  onSubmit(): void {
    console.log(this.personalForm.value);
  }

  onLoadDataClick(): void {
    this.personalForm.setValue({
      firstName: 'Rajendra',
      lastName: 'Taradale',
      address: 'Dhanori Pune',
      other: {
        education: 'B C A',
        age: 30,
        gendar: 'male'
      }
    });
  }


  onsetValueClick(): void {
    this.personalForm.setValue({
      firstName: '',
      lastName: '',
      address: '',
      // other: {
      //   education: 'B Tech',
      //   age: 30,
      //   gendar: 'male'
      // }
    });
  }

  onpatchValueClick(): void {
    this.personalForm.patchValue({
      firstName: 'Rajendra',
      lastName: 'Taradale',
      address: '',
      // other: {
      //   education: '',
      //   age: '',
      //   gendar: ''
      // }
    });
  }

  onClearDataClick(){
    this.personalForm.reset();
  }
}
